import PlaylistSection from "@/components/PlaylistSection";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Playlist creation - My movies",
  description: "Playlist Creation Page",
};

function PlaylistCreationPage() {
  return <PlaylistSection />;
}

export default PlaylistCreationPage;
