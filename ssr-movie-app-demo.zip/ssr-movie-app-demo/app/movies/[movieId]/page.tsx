import ClientHead from "@/components/ClientHead";
import MovieSection from "@/components/MovieSection";
import { fetchMovie } from "@/services/api/tmdb";
import { notFound } from "next/navigation";
import { Suspense } from "react";
import PageHead from "./PageHead";

type Props = {
  params: {
    movieId: string;
  };
};

function handleParams(params: Props["params"]): number {
  const movieId = Number(params.movieId);

  const isMovieIdValid = Number.isInteger(movieId) && movieId > 0;
  if (!isMovieIdValid) {
    return notFound();
  }

  return movieId;
}

export async function generateMetadata({ params }: Props) {
  const movieId = handleParams(params);

  return {
    title: `${movieId} - My movies`,
    description: `Page details of movie: ${movieId}`,
  };
}

function MoviePage({ params }: Props) {
  const movieId = handleParams(params);

  return (
    <>
      <Suspense>
        <PageHead movieId={movieId} />
      </Suspense>

      <h1>MoviePage</h1>
      <Suspense fallback={<div>Loading...</div>}>
        <MovieSection movieId={movieId} />
      </Suspense>
    </>
  );
}

export default MoviePage;
