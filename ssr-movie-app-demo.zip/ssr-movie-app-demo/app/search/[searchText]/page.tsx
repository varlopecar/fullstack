import SearchResult from "@/components/SearchResult";
import { Metadata } from "next";
import { Suspense } from "react";

type Props = {
  params: {
    searchText: string;
  };
};

export function generateMetadata({ params }: Props): Metadata {
  return {
    title: `Search: ${params.searchText} - My movies`,
    description: `Search results for ${params.searchText}`,
  };
}

async function SearchTextPage({ params }: Props) {
  const { searchText } = params;

  return (
    <>
      <h1>SearchTextPage</h1>
      <p>Search text: {decodeURI(searchText)}</p>
      <Suspense fallback={<div>Loading...</div>}>
        <SearchResult searchText={searchText} />
      </Suspense>
    </>
  );
}

export default SearchTextPage;
