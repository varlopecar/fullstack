import SearchBar from "@/components/SearchBar";
import classes from "./page.module.css";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Search - My movies",
  description: "Search for movies",
};

function SearchPage() {
  return (
    <div className={classes.root}>
      <SearchBar />
    </div>
  );
}

export default SearchPage;
