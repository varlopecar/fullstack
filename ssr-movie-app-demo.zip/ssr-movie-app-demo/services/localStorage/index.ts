import localStoragePlaylist from "./playlist";

const LocalStorageService = {
  playlist: localStoragePlaylist,
};

export default LocalStorageService;
