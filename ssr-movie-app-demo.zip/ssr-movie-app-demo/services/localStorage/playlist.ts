import LocalStoragePlaylist from "@/models/LocalStoragePlaylist";
import Movie from "@/models/Movie";

const localStorageKey = "playlist";

const defaultPlaylist: LocalStoragePlaylist = {
  name: "",
  description: "",
  movies: [],
};

function get(): LocalStoragePlaylist {
  const localStoragePlaylist = localStorage.getItem(localStorageKey);
  if (!localStoragePlaylist) {
    return defaultPlaylist;
  }

  return JSON.parse(localStoragePlaylist);
}

function set(playlist: LocalStoragePlaylist): void {
  localStorage.setItem(localStorageKey, JSON.stringify(playlist));
}

function addMovie(movie: Movie): void {
  const localStoragePlaylist = get();

  if (localStoragePlaylist.movies.find((m) => m.id === movie.id)) {
    return;
  }

  const updatedPlaylist = {
    ...localStoragePlaylist,
    movies: [...localStoragePlaylist.movies, movie],
  };

  set(updatedPlaylist);
}

function deleteMovie(movie: Movie): void {
  const localStoragePlaylist = get();

  const updatedPlaylist = {
    ...localStoragePlaylist,
    movies: localStoragePlaylist.movies.filter((m) => m.id !== movie.id),
  };

  set(updatedPlaylist);
}

function setMetadata(name: string, description: string): LocalStoragePlaylist {
  const localStoragePlaylist = get();

  const updatedPlaylist = {
    ...localStoragePlaylist,
    name,
    description,
  };

  set(updatedPlaylist);

  return updatedPlaylist;
}

const localStoragePlaylist = {
  addMovie,
  get,
  deleteMovie,
  setMetadata,
};

export default localStoragePlaylist;
