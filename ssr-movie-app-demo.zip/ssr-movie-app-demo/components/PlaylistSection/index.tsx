"use client";

import LocalStoragePlaylist from "@/models/LocalStoragePlaylist";
import LocalStorageService from "@/services/localStorage";
import { useEffect, useRef, useState } from "react";
import PlaylistMovies from "../PlaylistMovies";
import Movie from "@/models/Movie";
import { Box, Button, TextField } from "@mui/material";

function PlaylistSection() {
  const [playlist, setPlaylist] = useState<LocalStoragePlaylist | null>(null);
  const nameInputRef = useRef<HTMLInputElement>(null);
  const descriptionInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setPlaylist(LocalStorageService.playlist.get());
  }, []);

  const handleMovieDeletion = (movie: Movie) => {
    LocalStorageService.playlist.deleteMovie(movie);
    setPlaylist(LocalStorageService.playlist.get());
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const name = nameInputRef.current?.value;
    const description = descriptionInputRef.current?.value;

    if (!name || !description) {
      return;
    }

    const updatedPlaylist = LocalStorageService.playlist.setMetadata(
      name,
      description
    );

    setPlaylist(updatedPlaylist);
  };

  if (!playlist) {
    return null;
  }

  return (
    <div>
      <Box
        component="form"
        onSubmit={handleSubmit}
        display="flex"
        flexDirection="column"
        gap="20px"
        alignItems="center"
      >
        <TextField
          inputRef={nameInputRef}
          label="Playlist name"
          fullWidth
          defaultValue={playlist.name}
        />
        <TextField
          inputRef={descriptionInputRef}
          label="Playlist description"
          fullWidth
          defaultValue={playlist.description}
        />
        <Button variant="contained" type="submit" color="primary" size="large">
          Save the playlist
        </Button>
      </Box>
      <PlaylistMovies
        movies={playlist.movies}
        onMovieDeletion={handleMovieDeletion}
      />
    </div>
  );
}

export default PlaylistSection;
