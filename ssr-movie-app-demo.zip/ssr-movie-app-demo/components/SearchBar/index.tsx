"use client";

import { InputAdornment, TextField } from "@mui/material";
import SearchIcon from "../SearchIcon";
import { useRef } from "react";
import { useRouter } from "next/navigation";

function SearchBar() {
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  const handleSearch = () => {
    const inputValue = inputRef.current?.value;
    if (!inputValue) {
      return;
    }

    router.push(`search/${inputValue}`);
  };

  const onSearchKeyDown = (event: React.KeyboardEvent<HTMLDivElement>) => {
    if (event.key === "Enter") {
      handleSearch();
    }
  };

  return (
    <TextField
      inputRef={inputRef}
      InputProps={{
        endAdornment: (
          <InputAdornment position="end">
            <SearchIcon onClick={handleSearch} />
          </InputAdornment>
        ),
      }}
      color="primary"
      variant="outlined"
      placeholder="Search..."
      size="small"
      onKeyDown={onSearchKeyDown}
    />
  );
}

export default SearchBar;
