function MainFooter() {
  return <p>Footer</p>;
}

export default MainFooter;
