"use client";

import { Theme } from "@emotion/react";
import { SxProps, TableRow } from "@mui/material";
import { useRouter } from "next/navigation";
import { PropsWithChildren } from "react";

type Props = {
  sx: SxProps<Theme>;
  className: string;
  linkHref: string;
};

function ClientTableRow({
  sx,
  className,
  linkHref,
  children,
}: PropsWithChildren<Props>) {
  const router = useRouter();

  const handleClick = () => {
    router.push(linkHref);
  };

  return (
    <TableRow sx={sx} className={className} onClick={handleClick}>
      {children}
    </TableRow>
  );
}

export default ClientTableRow;
