import { fetchMovie } from "@/services/api/tmdb";
import MovieCard from "../MovieCard";
import { Button } from "@mui/material";
import AddToPlaylistButton from "./AddToPlaylistButton";

type Props = {
  movieId: number;
};

async function MovieSection({ movieId }: Props) {
  const movie = await fetchMovie(movieId);

  return (
    <section>
      <AddToPlaylistButton movie={movie} />
      <MovieCard movie={movie} />
    </section>
  );
}

export default MovieSection;
