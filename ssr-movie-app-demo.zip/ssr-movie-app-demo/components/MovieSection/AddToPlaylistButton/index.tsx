"use client";

import Movie from "@/models/Movie";
import LocalStorageService from "@/services/localStorage";
import { Button } from "@mui/material";

type Props = {
  movie: Movie;
};

function AddToPlaylistButton({ movie }: Props) {
  const handleClick = () => {
    LocalStorageService.playlist.addMovie(movie);
  };

  return (
    <Button variant="outlined" onClick={handleClick}>
      Add to playlist
    </Button>
  );
}

export default AddToPlaylistButton;
