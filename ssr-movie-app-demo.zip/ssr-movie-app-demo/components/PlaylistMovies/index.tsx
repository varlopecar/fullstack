import {
  TableContainer,
  Paper,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Button,
} from "@mui/material";
import ClientTableRow from "../ClientTableRow";
import classes from "./index.module.css";
import Movie from "@/models/Movie";
import LocalStorageService from "@/services/localStorage";
import LocalStoragePlaylist from "@/models/LocalStoragePlaylist";

type Props = {
  movies: Movie[];
  onMovieDeletion: (movie: Movie) => void;
};

function PlaylistMovies({ movies, onMovieDeletion }: Props) {
  const handleClickOnDeleteMovie =
    (movie: Movie) => (event: React.MouseEvent<HTMLButtonElement>) => {
      event.preventDefault();
      event.stopPropagation();
      onMovieDeletion(movie);
    };

  return (
    <TableContainer className={classes.root} component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="movies playlist table">
        <TableHead>
          <TableRow>
            <TableCell align="center" className={classes.tableCell}>
              ID
            </TableCell>
            <TableCell align="center" className={classes.tableCell}>
              Title
            </TableCell>
            <TableCell align="center" className={classes.tableCell}>
              Vote average
            </TableCell>
            <TableCell align="center" className={classes.tableCell}>
              Vote count
            </TableCell>
            <TableCell align="center" className={classes.tableCell}>
              Popularity
            </TableCell>
            <TableCell align="center" className={classes.tableCell}>
              Release date
            </TableCell>
            <TableCell align="center" className={classes.tableCell}>
              Playlist deletion
            </TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {movies.map((movie) => (
            <ClientTableRow
              key={movie.id}
              sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
              className={classes.row}
              linkHref={`/movies/${movie.id}`}
            >
              <TableCell align="center">{movie.id}</TableCell>
              <TableCell align="center">{movie.title}</TableCell>
              <TableCell align="center">{movie.vote_average}</TableCell>
              <TableCell align="center">{movie.vote_count}</TableCell>
              <TableCell align="center">{movie.popularity}</TableCell>
              <TableCell align="center">{movie.release_date}</TableCell>
              <TableCell align="center">
                <Button onClick={handleClickOnDeleteMovie(movie)} color="error">
                  Delete
                </Button>
              </TableCell>
            </ClientTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

export default PlaylistMovies;
