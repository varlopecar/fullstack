import Movie from "./Movie";

type LocalStoragePlaylist = {
  name: string;
  description: string;
  movies: Movie[];
};

export default LocalStoragePlaylist;
