import { useContext } from "react";
import { PostContext } from "../contexts/PostContext";

export const usePost = () => {
  const context = useContext(PostContext);

  if (context === undefined) {
    throw new Error("usePostContext must be used within a PostContextProvider");
  }

  return context;
};
