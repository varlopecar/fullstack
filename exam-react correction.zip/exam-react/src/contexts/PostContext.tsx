import { PropsWithChildren, createContext, useCallback, useState } from "react";
import Post from "../models/Post";
import { useNavigate } from "react-router-dom";
import { getPost } from "../services/getPosts";

type PostContextType = {
  post: Post | undefined;
  isLoading: boolean;
  error: boolean;
  fetchPost: (id: string) => Promise<void>;
};

export const PostContext = createContext<PostContextType | undefined>(
  undefined
);

const PostContextProvider = ({ children }: PropsWithChildren) => {
  const [post, setPost] = useState<Post | undefined>(undefined);

  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<boolean>(false);

  const fetchPost = useCallback(
    async (id: string) => {
      try {
        setIsLoading(true);
        const post = await getPost(id);
        setPost(post);
      } catch (error) {
        navigate("/not-found");
        setError(true);
      } finally {
        setIsLoading(false);
      }
    },
    [navigate]
  );

  return (
    <PostContext.Provider value={{ post, error, fetchPost, isLoading }}>
      {children}
    </PostContext.Provider>
  );
};

export default PostContextProvider;
