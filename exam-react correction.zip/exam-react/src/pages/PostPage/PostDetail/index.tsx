import { useEffect } from "react";
import PostCard from "../../../components/PostCard";
import { usePost } from "../../../hooks/usePost";
import { useParams } from "react-router-dom";

const PostDetailPage = () => {
  const { postId } = useParams<{ postId: string }>();
  const { post, fetchPost } = usePost();

  useEffect(() => {
    fetchPost(postId!);
  }, [fetchPost, postId]);

  return (
    <div>
      <PostCard post={post} />
    </div>
  );
};

export default PostDetailPage;
